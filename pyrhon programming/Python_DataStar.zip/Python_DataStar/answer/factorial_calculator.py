# MC

result = 1
while True:
    value = input('Enter a positive number: ')
    try:
        n = int(value)
    except ValueError:
        print('Please enter a valid number')
        continue
        
    if n>0:
        break
    else:
        print('Please enter a positive number')

for i in range(n):
    result *= i+1
    
print(result)