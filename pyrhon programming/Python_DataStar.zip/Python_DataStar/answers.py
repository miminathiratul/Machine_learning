ten_companies =['Agilent Technologies Inc.',
 'Alcoa, Inc.',
 'WCM/BNY Mellon Focused Growth ADR ETF',
 'iShares MSCI AC Asia Information Tech',
 'Altisource Asset Management Corporation',
 'Atlantic American Corp.',
 "Aaron's, Inc.",
 'Applied Optoelectronics, Inc.',
 'AAON Inc.',
 'Advance Auto Parts Inc.']

inc_companies = ['Agilent Technologies Inc.', 'Alcoa, Inc.', "Aaron's, Inc.", 'Applied Optoelectronics, Inc.', 'AAON Inc.', 'Advance Auto Parts Inc.']

the_salaries = [{'name': 'John', 'salary': 5000, 'years_employed': 4},
 {'name': 'Lee', 'salary': 4000, 'years_employed': 3},
 {'name': 'Alex', 'salary': 3000, 'years_employed': 7},
 {'name': 'John', 'salary': 3000, 'years_employed': 8},
 {'name': 'Lauren', 'salary': 6000, 'years_employed': 5}]

wooper_desc = 'Wooper usually lives in water. However, it occasionally comes\nout onto land in search of food. On land, it coats its body with\na gooey, toxic film.'