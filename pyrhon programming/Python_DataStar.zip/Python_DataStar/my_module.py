
def mult_two(x, y):
    return x * y

def capitalize_string(string):
    return string.capitalize()