
states_and_capitals = [
    ['Perlis','Kangar'],
    ['Kedah','Alor Setar'],
    ['Pulau Pinang','George Town'],
    ['Perak','Ipoh'],
    ['Pahang','Kuantan'],
    ['Selangor','Shah Alam'],
    ['Negeri Sembilan','Seremban'],
    ['Kelantan','Kota Bharu'],
    ['Terengganu','Kuala Terengganu'],
    ['Melaka','Bandar Melaka'],
    ['Johor','Johor Bahru'],
    ['Sarawak','Kuching'],
    ['Sabah','Kota Kinabalu'],
]

import random
state, capital = random.choice(states_and_capitals)
state

i = 0
while i < 3:
    print(f"What is the capital of {state}?")
    answer = input()
    if answer.lower() == capital.lower():
        print("Correct! Good job!")
        break
    elif i<2:
        print("Sorry, that's incorrect, please try again")
        i += 1
    else:
        print("Sorry, that's incorrect and you have used all 3 chances")
        i += 1